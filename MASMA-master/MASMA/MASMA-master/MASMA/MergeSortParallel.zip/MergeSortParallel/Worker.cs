﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ActressMas;
using MASMA.Message;
namespace MASMA.MergeSortParallel
{

    class Worker : Agent
    {
        int[] data;

        public Worker()
        {
            data = new int[1000];
        }

        public override void Act(ActressMas.Message message)
        {
            try
            {
                Console.WriteLine("\t[{1} -> {0}]: {2}", this.Name, message.Sender, message.Content);

                string action;
                string parameters;
                Utils.ParseMessage(message.Content, out action, out parameters);

                switch (action)
                {

                    case "sort-asignData":
                        SortAndAssign(parameters);
                        Send(Agents.MasterAgent, "done-sort-asignData");
                        break;
                    //i+1
                    case "merge-and-compare":
                        //send i -> data  ->merge
                        int index = Utils.agentPool.IndexOf(this.Name);
                        if (index != 0 && index != Utils.numAg)
                            Send(Utils.agentPool[index - 1], Utils.Str("merge", fromArrayToString(this.data)));
                        Utils.agentPool.Remove(this.Name);
                        Stop();
                        //stop
                        break;
                    case "merge":
                        int[] received = fromStringToArray(parameters);
                        int[] own = this.data;
                        int[] result = received
                             .Concat(own)
                             .OrderBy(x => x)
                             .ToArray();


                        this.data = result;

                        break;
                    case "print":

                        Console.WriteLine();
                        for (int i = 0; i < data.Length; i++)
                        {
                            Utils.Destination[i] = data[i];
                            Console.Write(data[i] + "_  ");
                        }
                        Stop();
                        break;
                    case "terminate":
                        Utils.agentPool.Remove(this.Name);
                        Stop();
                        break;
                }
            }
            catch (Exception e)
            {
                Stop();
            }

        }
        string fromArrayToString(int[] arr)
        {
            string ret = "";
            for (int i = 0; i < arr.Length; i++)
            {
                ret = ret + arr[i] + ",";
            }
            return ret.Remove(ret.Length - 1);
        }
        void SortAndAssign(String data)
        {
            string[] spl = data.Split(',');
            int[] ret = new int[spl.Length];
            for (int i = 0; i < spl.Length; i++)
            {
                ret[i] = Int32.Parse(spl[i]);

            }
            this.data = ret;
            Sort();
        }
        int[] fromStringToArray(String data)
        {
            string[] spl = data.Split(',');
            int[] ret = new int[spl.Length];
            for (int i = 0; i < spl.Length; i++)
            {
                ret[i] = Int32.Parse(spl[i]);

            }
            return ret;

        }
        void Sort()
        {
            Array.Sort(this.data);
        }
    }
}

